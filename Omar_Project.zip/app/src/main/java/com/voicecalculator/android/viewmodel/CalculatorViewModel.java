package com.voicecalculator.android.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public class CalculatorViewModel extends ViewModel {

    private final MutableLiveData<String> currentValue = new MutableLiveData<>("0");
    private final MutableLiveData<String> previousValue = new MutableLiveData<>(null);
    private final MutableLiveData<String> operation = new MutableLiveData<>(null);
    private final MutableLiveData<Boolean> waitingForNewValue = new MutableLiveData<>(false);
    private final MutableLiveData<Boolean> isVoiceListening = new MutableLiveData<>(false);
    private final MutableLiveData<String> voiceStatus = new MutableLiveData<>("Voice Ready");
    private final MutableLiveData<String> errorMessage = new MutableLiveData<>(null);

    public LiveData<String> getCurrentValue() { return currentValue; }
    public LiveData<String> getPreviousValue() { return previousValue; }
    public LiveData<String> getOperation() { return operation; }
    public LiveData<Boolean> getWaitingForNewValue() { return waitingForNewValue; }
    public LiveData<Boolean> getIsVoiceListening() { return isVoiceListening; }
    public LiveData<String> getVoiceStatus() { return voiceStatus; }
    public LiveData<String> getErrorMessage() { return errorMessage; }

    public void inputNumber(String num) {
        Boolean waiting = waitingForNewValue.getValue();
        String current = currentValue.getValue();
        if (Boolean.TRUE.equals(waiting)) {
            currentValue.setValue(num);
            waitingForNewValue.setValue(false);
        } else {
            currentValue.setValue("0".equals(current) ? num : current + num);
        }
    }

    public void inputDecimal() {
        Boolean waiting = waitingForNewValue.getValue();
        String current = currentValue.getValue();
        if (Boolean.TRUE.equals(waiting)) {
            currentValue.setValue("0.");
            waitingForNewValue.setValue(false);
        } else if (current != null && !current.contains(".")) {
            currentValue.setValue(current + ".");
        }
    }

    public void handleOperation(String nextOperation) {
        String currentStr = currentValue.getValue();
        if (currentStr == null) return;

        Double inputValue = parseDouble(currentStr);
        if (inputValue == null) return;

        String prevStr = previousValue.getValue();
        String currentOp = operation.getValue();

        if (prevStr == null) {
            previousValue.setValue(currentStr);
        } else if (currentOp != null) {
            Double prevValue = parseDouble(prevStr);
            if (prevValue == null) return;

            Double result = calculate(prevValue, inputValue, currentOp);
            if (result != null) {
                String formatted = formatResult(result);
                currentValue.setValue(formatted);
                previousValue.setValue(formatted);
            } else {
                return;
            }
        }

        waitingForNewValue.setValue(true);
        operation.setValue(nextOperation);
    }

    public void performCalculation() {
        String prevStr = previousValue.getValue();
        String currentOp = operation.getValue();
        String currentStr = currentValue.getValue();

        if (prevStr == null || currentOp == null || currentStr == null) return;

        Double prevValue = parseDouble(prevStr);
        Double inputValue = parseDouble(currentStr);
        if (prevValue == null || inputValue == null) return;

        Double result = calculate(prevValue, inputValue, currentOp);
        if (result != null) {
            currentValue.setValue(formatResult(result));
            previousValue.setValue(null);
            operation.setValue(null);
            waitingForNewValue.setValue(true);
        }
    }

    private Double calculate(double first, double second, String op) {
        switch (op) {
            case "+": return first + second;
            case "-": return first - second;
            case "*": return first * second;
            case "/":
                if (second == 0.0) {
                    showError("Cannot divide by zero");
                    return null;
                }
                return first / second;
            default: return null;
        }
    }

    private String formatResult(double result) {
        if (result == (long) result) {
            return String.valueOf((long) result);
        } else {
            return String.valueOf(Math.round(result * 100000000.0) / 100000000.0);
        }
    }

    public void clearCalculator() {
        currentValue.setValue("0");
        previousValue.setValue(null);
        operation.setValue(null);
        waitingForNewValue.setValue(false);
    }

    public void backspace() {
        String current = currentValue.getValue();
        if (current != null && current.length() > 1) {
            currentValue.setValue(current.substring(0, current.length() - 1));
        } else {
            currentValue.setValue("0");
        }
    }

    public void setVoiceListening(boolean listening) {
        isVoiceListening.setValue(listening);
    }

    public void setVoiceStatus(String status) {
        voiceStatus.setValue(status);
    }

    public void showError(final String message) {
        errorMessage.setValue(message);
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(
            () -> errorMessage.setValue(null), 3000
        );
    }

    public void processVoiceCommand(String transcript) {
        try {
            String lower = transcript.toLowerCase().trim();

            if (lower.contains("clear") || lower.contains("reset")) {
                clearCalculator();
                return;
            }

            String mathExpression = speechToMathExpression(lower);

            if (mathExpression.isEmpty()) {
                showError("Could not understand the math expression");
                return;
            }

            double result = evaluateExpression(mathExpression);
            currentValue.setValue(formatResult(result));
            previousValue.setValue(null);
            operation.setValue(null);
            waitingForNewValue.setValue(true);

        } catch (Exception e) {
            showError("Error processing voice command: " + e.getMessage());
        }
    }

    private String speechToMathExpression(String speech) {
        String expression = speech;

        String[] words = expression.split("\\s+");
        List<String> uniqueWords = new ArrayList<>();
        for (int i = 0; i < words.length; i++) {
            if (i == 0 || !words[i].equals(words[i - 1])) {
                uniqueWords.add(words[i]);
            }
        }
        expression = String.join(" ", uniqueWords);

        Map<String, String> numberWords = new HashMap<>();
        numberWords.put("zero", "0"); numberWords.put("one", "1"); numberWords.put("two", "2");
        numberWords.put("three", "3"); numberWords.put("four", "4"); numberWords.put("five", "5");
        numberWords.put("six", "6"); numberWords.put("seven", "7"); numberWords.put("eight", "8");
        numberWords.put("nine", "9"); numberWords.put("ten", "10"); numberWords.put("eleven", "11");
        numberWords.put("twelve", "12"); numberWords.put("thirteen", "13"); numberWords.put("fourteen", "14");
        numberWords.put("fifteen", "15"); numberWords.put("sixteen", "16"); numberWords.put("seventeen", "17");
        numberWords.put("eighteen", "18"); numberWords.put("nineteen", "19"); numberWords.put("twenty", "20");
        numberWords.put("thirty", "30"); numberWords.put("forty", "40"); numberWords.put("fifty", "50");
        numberWords.put("sixty", "60"); numberWords.put("seventy", "70"); numberWords.put("eighty", "80");
        numberWords.put("ninety", "90");

        for (Map.Entry<String, String> entry : numberWords.entrySet()) {
            expression = expression.replaceAll("\\b" + entry.getKey() + "\\b", entry.getValue());
        }

        expression = expression.replaceAll("\\bplus\\b|\\badd\\b", "+");
        expression = expression.replaceAll("\\bminus\\b|\\bsubtract\\b", "-");
        expression = expression.replaceAll("\\btimes\\b|\\bmultiply\\b|\\bmultiplied by\\b", "*");
        expression = expression.replaceAll("\\bdivided by\\b|\\bdivide\\b", "/");
        expression = expression.replaceAll("\\bequals?\\b|\\bequal\\b|\\bis\\b", "");
        expression = expression.replaceAll("[^0-9+\\-*/.\\s]", "");
        expression = expression.replaceAll("\\s+", "");

        return expression;
    }

    private double evaluateExpression(String expression) throws Exception {
        if (!Pattern.matches("^[0-9+\\-*/.()]+$", expression)) {
            throw new IllegalArgumentException("Invalid expression");
        }
        if (expression.contains("/0")) {
            throw new ArithmeticException("Cannot divide by zero");
        }

        if (expression.contains("+")) {
            String[] parts = expression.split("\\+");
            if (parts.length == 2) return Double.parseDouble(parts[0]) + Double.parseDouble(parts[1]);
        } else if (expression.contains("-") && !expression.startsWith("-")) {
            String[] parts = expression.split("-");
            if (parts.length == 2) return Double.parseDouble(parts[0]) - Double.parseDouble(parts[1]);
        } else if (expression.contains("*")) {
            String[] parts = expression.split("\\*");
            if (parts.length == 2) return Double.parseDouble(parts[0]) * Double.parseDouble(parts[1]);
        } else if (expression.contains("/")) {
            String[] parts = expression.split("/");
            if (parts.length == 2) {
                double divisor = Double.parseDouble(parts[1]);
                if (divisor == 0) throw new ArithmeticException("Cannot divide by zero");
                return Double.parseDouble(parts[0]) / divisor;
            }
        }
        return Double.parseDouble(expression);
    }

    private Double parseDouble(String value) {
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
