package com.voicecalculator.android;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;

import com.voicecalculator.android.databinding.ActivityMainBinding;
import com.voicecalculator.android.viewmodel.CalculatorViewModel;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private CalculatorViewModel viewModel;
    private SpeechRecognizer speechRecognizer;

    private final ActivityResultLauncher<String> requestPermissionLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
            if (isGranted) {
                initializeSpeechRecognizer();
            } else {
                Toast.makeText(this,
                    "Microphone permission is required for voice recognition",
                    Toast.LENGTH_LONG).show();
            }
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        viewModel = new ViewModelProvider(this).get(CalculatorViewModel.class);

        checkMicrophonePermission();
        setupObservers();
        setupButtons();
    }

    private void setupObservers() {
        viewModel.getCurrentValue().observe(this, value -> {
            Boolean waiting = viewModel.getWaitingForNewValue().getValue();
            String op = viewModel.getOperation().getValue();
            binding.tvDisplay.setText((Boolean.TRUE.equals(waiting) && op != null) ? "0" : value);
        });

        viewModel.getWaitingForNewValue().observe(this, waiting -> {
            String current = viewModel.getCurrentValue().getValue();
            String op = viewModel.getOperation().getValue();
            binding.tvDisplay.setText((Boolean.TRUE.equals(waiting) && op != null) ? "0" : current);
        });

        viewModel.getPreviousValue().observe(this, prev -> {
            String op = viewModel.getOperation().getValue();
            if (prev != null && op != null) {
                binding.tvPreviousValue.setText(prev + " " + op);
            } else {
                binding.tvPreviousValue.setText("");
            }
        });

        viewModel.getOperation().observe(this, op -> {
            String prev = viewModel.getPreviousValue().getValue();
            if (prev != null && op != null) {
                binding.tvPreviousValue.setText(prev + " " + op);
            } else {
                binding.tvPreviousValue.setText("");
            }
        });

        viewModel.getIsVoiceListening().observe(this, listening -> {
            if (Boolean.TRUE.equals(listening)) {
                binding.btnVoice.setText("⏹");
                binding.btnVoice.setBackgroundColor(Color.parseColor("#DC2626"));
                binding.voiceListeningCard.setVisibility(View.VISIBLE);
                binding.statusDot.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(Color.parseColor("#10B981")));
            } else {
                binding.btnVoice.setText("🎤");
                binding.btnVoice.setBackgroundColor(Color.parseColor("#10B981"));
                binding.voiceListeningCard.setVisibility(View.GONE);
                binding.statusDot.setBackgroundTintList(
                    android.content.res.ColorStateList.valueOf(Color.parseColor("#9CA3AF")));
            }
        });

        viewModel.getVoiceStatus().observe(this, status -> {
            binding.tvVoiceStatus.setText(status);
            binding.tvVoiceListeningStatus.setText(status);
        });

        viewModel.getErrorMessage().observe(this, error -> {
            if (error != null) {
                binding.tvError.setText(error);
                binding.errorCard.setVisibility(View.VISIBLE);
            } else {
                binding.errorCard.setVisibility(View.GONE);
            }
        });
    }

    private void setupButtons() {
        binding.btn0.setOnClickListener(v -> viewModel.inputNumber("0"));
        binding.btn1.setOnClickListener(v -> viewModel.inputNumber("1"));
        binding.btn2.setOnClickListener(v -> viewModel.inputNumber("2"));
        binding.btn3.setOnClickListener(v -> viewModel.inputNumber("3"));
        binding.btn4.setOnClickListener(v -> viewModel.inputNumber("4"));
        binding.btn5.setOnClickListener(v -> viewModel.inputNumber("5"));
        binding.btn6.setOnClickListener(v -> viewModel.inputNumber("6"));
        binding.btn7.setOnClickListener(v -> viewModel.inputNumber("7"));
        binding.btn8.setOnClickListener(v -> viewModel.inputNumber("8"));
        binding.btn9.setOnClickListener(v -> viewModel.inputNumber("9"));

        binding.btnDot.setOnClickListener(v -> viewModel.inputDecimal());
        binding.btnClear.setOnClickListener(v -> viewModel.clearCalculator());
        binding.btnBackspace.setOnClickListener(v -> viewModel.backspace());
        binding.btnEquals.setOnClickListener(v -> viewModel.performCalculation());

        binding.btnAdd.setOnClickListener(v -> viewModel.handleOperation("+"));
        binding.btnSubtract.setOnClickListener(v -> viewModel.handleOperation("-"));
        binding.btnMultiply.setOnClickListener(v -> viewModel.handleOperation("*"));
        binding.btnDivide.setOnClickListener(v -> viewModel.handleOperation("/"));

        binding.btnVoice.setOnClickListener(v -> startVoiceRecognition());
    }

    private void checkMicrophonePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED) {
            initializeSpeechRecognizer();
        } else {
            requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO);
        }
    }

    private void initializeSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new VoiceRecognitionListener(viewModel));
        } else {
            Toast.makeText(this, "Speech recognition not available on this device",
                Toast.LENGTH_SHORT).show();
        }
    }

    private void startVoiceRecognition() {
        if (speechRecognizer == null) {
            Toast.makeText(this, "Speech recognition not initialized", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a math expression like 'two plus three'");
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);

        viewModel.setVoiceListening(true);
        speechRecognizer.startListening(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
    }
}
