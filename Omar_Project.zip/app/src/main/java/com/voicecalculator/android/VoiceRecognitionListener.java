package com.voicecalculator.android;

import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;

import com.voicecalculator.android.viewmodel.CalculatorViewModel;

import java.util.ArrayList;

public class VoiceRecognitionListener implements RecognitionListener {

    private final CalculatorViewModel viewModel;

    public VoiceRecognitionListener(CalculatorViewModel viewModel) {
        this.viewModel = viewModel;
    }

    @Override
    public void onReadyForSpeech(Bundle params) {
        viewModel.setVoiceStatus("Ready to listen...");
    }

    @Override
    public void onBeginningOfSpeech() {
        viewModel.setVoiceStatus("Listening...");
    }

    @Override
    public void onRmsChanged(float rmsdB) {
    }

    @Override
    public void onBufferReceived(byte[] buffer) {
    }

    @Override
    public void onEndOfSpeech() {
        viewModel.setVoiceStatus("Processing...");
    }

    @Override
    public void onError(int error) {
        String errorMessage;
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO:             errorMessage = "Audio recording error"; break;
            case SpeechRecognizer.ERROR_CLIENT:            errorMessage = "Client side error"; break;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: errorMessage = "Insufficient permissions"; break;
            case SpeechRecognizer.ERROR_NETWORK:           errorMessage = "Network error"; break;
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:   errorMessage = "Network timeout"; break;
            case SpeechRecognizer.ERROR_NO_MATCH:          errorMessage = "No speech match found"; break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:   errorMessage = "Recognition service busy"; break;
            case SpeechRecognizer.ERROR_SERVER:            errorMessage = "Server error"; break;
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:    errorMessage = "No speech input"; break;
            default:                                       errorMessage = "Unknown error"; break;
        }

        viewModel.setVoiceListening(false);
        viewModel.setVoiceStatus("Voice Ready");
        viewModel.showError("Voice recognition error: " + errorMessage);
    }

    @Override
    public void onResults(Bundle results) {
        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches != null && !matches.isEmpty()) {
            viewModel.processVoiceCommand(matches.get(0));
        } else {
            viewModel.showError("No speech recognized");
        }
        viewModel.setVoiceListening(false);
        viewModel.setVoiceStatus("Voice Ready");
    }

    @Override
    public void onPartialResults(Bundle partialResults) {
        ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches != null && !matches.isEmpty()) {
            viewModel.setVoiceStatus("Heard: \"" + matches.get(0) + "\"");
        }
    }

    @Override
    public void onEvent(int eventType, Bundle params) {
    }
}
